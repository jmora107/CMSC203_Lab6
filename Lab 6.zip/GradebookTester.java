import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class GradebookTester {

    GradeBook a;
    GradeBook b;

    @Before
    public void setUp() throws Exception {
        a = new GradeBook(5);
        a.addScore(70);
        a.addScore(81);
        a.addScore(95);
        a.addScore(89);
        a.addScore(99);

        b = new GradeBook(5);
        b.addScore(56);
        b.addScore(78);
        b.addScore(91);
        b.addScore(92);
        b.addScore(80);
    }

    @After
    public void tearDown() throws Exception {
        a = null;
        b = null;
    }

    @Test
    public void testAddScore() {
        assertTrue(a.toString().equals("70.0 81.0 95.0 89.0 99.0 "));
        assertTrue(b.toString().equals("56.0 78.0 91.0 92.0 80.0 "));
    }

    @Test
    public void testSum() {
        assertEquals(434, a.sum(), .0001);
        assertEquals(397, b.sum(), .0001);
    }

    @Test
    public void testMinimum() {
        assertEquals(70, a.minimum(), .001);
        assertEquals(56, b.minimum(), .001);
    }

    @Test
    public void testFinalScore() {
        assertEquals(364, a.finalScore(), .0001);
        assertEquals(341, b.finalScore(), .0001);
    }


}
